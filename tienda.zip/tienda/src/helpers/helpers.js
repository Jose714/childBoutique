const hbs = require('hbs');

hbs.registerHelper('ver', (listado) => {
let texto = `	<form action="/shirt" method="post">
		<table class='table table-striped table-hover'> 
				<thead class='thead-dark'>
				<th>Nombre</th>
				<th>Precio</th>
				<th>Tipo</th>
				<th>Talla</th>
				<th>Agregar al carrito</th>
			
				</thead>
				<tbody>`;
	listado.forEach(producto =>{
		texto = texto + 
				`<tr>
				<th> ${producto.nombre} </th>
				<th> ${producto.precio} </th>
				<th> ${producto.tipo} </th>
				<th> ${producto.talla} </th>

				
			
				
				<td><button class="btn btn-danger" name="nombre" value="${producto.nombre}"><img src="img/carrito.png" width="50px" height="50px"></button></td>
				
				</tr> `;
	})
	texto = texto + '</tbody> </table></form>';	
	return texto;

});

	

	hbs.registerHelper('mirar', (listado) => {
		let texto = `<form action="/shirt" method="post">
			`;
			listado.forEach(producto =>{
				texto = texto + 
						`
						<p><input type="text"  class="card-text" value="${producto.nombre}" placeholder="${producto.nombre}"> </p>
						<p><input type="text" class="card-text" value"${producto.precio}" placeholder="${producto.precio}"></p>
						<p><input type="text" class="card-text" value="${producto.tipo}" placeholder="${producto.tipo}"></p>
						<p><input type="text" class="card-text" value=" ${producto.talla}" placeholder="${producto.talla}"></p>
						
						
						
					 `;
			})
			texto = texto + '</form>';	
			return texto;
		
		});
