const express = require('express')
const app = express ()
const path = require('path')
const hbs = require ('hbs')
const Producto = require('./../models/producto')
const dirViews = path.join(__dirname, '../../template/views')
const dirPartials = path.join(__dirname, '../../template/partials')
const bcrypt = require('bcrypt');


require('./../helpers/helpers')

//hbs
app.set('view engine', 'hbs')
app.set('views', dirViews)
hbs.registerPartials(dirPartials)

app.get('/gallery', (req, res ) => {
	Producto.find({},(err,respuesta)=>{
	res.render('gallery', {
		tituloPagina:'Gallery',
		listado : respuesta
	})
})	
});
app.get('/shirt', (req, res ) => {
	Producto.find({},(err,respuesta)=>{
	res.render('shirt', {
		tituloPagina:'Camisas ChilD',
		listado : respuesta
	})
})	
});

app.get('/registroProducto', (req, res ) => {
	Producto.find({},(err,respuesta)=>{
		if (err){
			return console.log(err)
		}
		else
	res.render('registroProducto', {
		tituloPagina:'Ingresar nuevo',
		listado : respuesta
		})
	})
		
});
app.post('/registroProducto', (req, res ) => {

	let producto = new Producto ({
		nombre : req.body.nombre,
		precio: req.body.precio,
		tipo : 	req.body.tipo,
		talla: req.body.talla,
		avatar:	req.body.avatar
	})
	producto.cliente=req.cliente.id;
	producto.save((err, resultado) => {
		if (err){
			return res.render ('indexpost', {
				mostrar : err
			})			
		}		
		res.render ('indexpost', {			
				mostrar : resultado.nombre
			})		
	})			
});
//fin registrar producto

//populate producto y cliente

app.get("/carrito", (req, res) => {
	Producto.findOne({nombre : req.body.nombre}, req.body, (err, usuario)  => {
		if (err){
			return console.log(err)
		}
		Cliente.populate(usuario, {path: "cliente"},function(err, producto){
			res.render ('agregar',{
				tituloPagina:'Agrgar al carrito',
				listado : producto
			})
        }); 
	})
	
})


//fin populate

app.post('/agregar', (req,res) => {

	Producto.findOne({nombre : req.body.nombre}, req.body, (err, resultado) => {
		if (err){
			return console.log(err)
		}
		Cliente.populate(resultado, {path: "cliente"},function(err, producto){
			res.render ('agregar',{
				tituloPagina:'Agrgar al carrito',
				nombre : producto
			})
		});
	
		

	
	})
})

//fin
module.exports = app