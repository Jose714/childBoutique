const express = require('express')
const app = express ()
const path = require('path')
const hbs = require ('hbs')
const Cliente = require('./../models/cliente')
const dirViews = path.join(__dirname, '../../template/views')
const dirPartials = path.join(__dirname, '../../template/partials')
const bcrypt = require('bcrypt');


require('./../helpers/helpers')

//hbs
app.set('view engine', 'hbs')
app.set('views', dirViews)
hbs.registerPartials(dirPartials)

//registrar estudiante


app.get('/registrar', (req, res ) => {
	res.render('registrar', {
		tituloPagina:'Registro',
	
	})	
});
app.post('/registrar',(req, res ) => {

	let cliente = new Cliente ({
		nombre : req.body.nombre,
		apellido:req.body.apellido,
		password : bcrypt.hashSync(req.body.password, 10),
		email: req.body.email,
		sexo: req.body.sexo	
	})
		
	
	cliente.save((err, resultado) => {
		if (err){
			return res.render ('indexpost', {
				mostrar : err
			})			
		}		
		res.render ('indexpost', {	
			tituloPagina:'Bienvenido',		
				mostrar : resultado.nombre
			})		
	})			
});

module.exports = app