const express = require('express')
const app = express()
var random = require('math-random')
const path = require('path')
const hbs = require('hbs')
const Cliente = require('./../models/cliente')
const Producto = require('./../models/producto')
const Carrito = require('./../models/find_product')
const Tarjeta = require('./../models/pago-tarjeta')
const dirViews = path.join(__dirname, '../../template/views')
const dirPartials = path.join(__dirname, '../../template/partials')
const bcrypt = require('bcrypt');
const multer = require('multer');

const { isAuthenticated } = require('./../helpers/auth');

require('./../helpers/helpers')

//hbs
app.set('view engine', 'hbs')
app.set('views', dirViews)
hbs.registerPartials(dirPartials)

//registrar cliente
app.get('/', (req, res) => {
	res.render('index', {
		tituloPagina: 'Child Boutique',
		titulo: 'Registro de estudiante',
	})
});
let code= console.log(random(55, 956)); // where 55 is minimum and 956 is maximum

app.get('/registrar', (req, res) => {
	res.render('registrar', {
		tituloPagina: 'Registro',

	})
});
app.post('/registrar', (req, res) => {
	console.log(req.file)
	let cliente = new Cliente({
		nombre: req.body.nombre,
		apellido: req.body.apellido,
		password: bcrypt.hashSync(req.body.password, 10),
		email: req.body.email,
		sexo: req.body.sexo,
		
	})


	cliente.save((err, resultado) => {
		if (err) {
			return res.render('indexpost', {
				mostrar: err
			})
		}
		res.render('indexpost', {
			tituloPagina: 'Bienvenido',
			mostrar: resultado.nombre
		})
	})
});

app.get('/registroProducto', (req, res) => {
	Producto.find({}, (err, respuesta) => {
		if (err) {
			return console.log(err)
		}
		else
			res.render('registroProducto', {
				tituloPagina: 'Ingresar nuevo',
				listado: respuesta
			})
	})

});
var upload = multer({})
app.post('/registroProducto', upload.single('archivo'), async (req, res) => {
	console.log(req.file)
	const newProd = new Producto({
		nombre: req.body.nombre,
		precio: req.body.precio,
		tipo: req.body.tipo,
		talla: req.body.talla,
		avatar: req.file.buffer
	});

	await newProd.save((err, resultado) => {
		if (err) {
			return res.render('indexpost', {
				mostrar: err
			})
		}
		res.render('indexpost', {
			tituloPagina: 'Bienvenido',
			mostrar: resultado.nombre

		})
		res.redirect('/');
	})
});




//fin registrar producto
//AGREGAR AL CARRITO
app.get('/shirt', async (req, res) => {
	const prod = await Producto.find({}).sort({ date: 'desc' });
	res.render('shirt', { prod })

});
//eliminar producto creado
app.post('/eliminar', (req, res) => {
	
	Carrito.findOneAndDelete({nombre : req.body.nombre}, req.body, (err, resultado) => {
		if (err){
			return console.log(err)
		}

		if(!resultado){
			res.render ('eliminar', {
			tituloPagina:'Eliminar',
			nombre : "no encontrado"			
		})

		}

		res.render ('eliminar', {
			tituloPagina:'Eliminar',
			nombre : resultado.nombre			
		})
	})	
})

app.post('/shirt', async (req, res) => {
	const { nombre, precio, tipo, talla } = req.body;
	const errors = [];
	if (!nombre) {
		errors.push({ text: 'Please Write a Title.' });
	}
	if (!precio) {
		errors.push({ text: 'Please Write a Description' });
	}
	if (!tipo) {
		errors.push({ text: 'Please Write a Title.' });
	}
	if (!talla) {
		errors.push({ text: 'Please Write a Title.' });
	}
	if (errors.length > 0) {
		res.render('indexpost', {
			errors,
			nombre,
			precio,
			tipo,
			talla
		});
	} else {
		const newCarrito = new Carrito({ nombre, precio, tipo, talla });
		newCarrito.user = req.session.usuario;

		const car = await newCarrito.save((err, resultado) => {
			if (err) {
				return res.render('indexpost', {
					mostrar: err
				})
			}
			res.render('indexpost', {
				tituloPagina: 'Bienvenido',
				mostrar: resultado.nombre,
				car
			})
			res.redirect('/carrito')
		})

	}
});

app.get('/carrito', async (req, res) => {
	const prod = await Carrito.find({ user: req.session.usuario }).sort({ date: 'desc' });
	res.render('carrito', { prod })

});

app.post('/carrito', async (req, res) => {
	const { nombre, precio, tipo, talla } = req.body;
	const errors = [];
	if (!nombre) {
		errors.push({ text: 'Please Write a Title.' });
	}
	if (!precio) {
		errors.push({ text: 'Please Write a Description' });
	}
	if (!tipo) {
		errors.push({ text: 'Please Write a Title.' });
	}
	if (!talla) {
		errors.push({ text: 'Please Write a Title.' });
	}
	if (errors.length > 0) {
		res.render('indexpost', {
			errors,
			nombre,
			precio,
			tipo,
			talla
		});
	} else {
		const newPago = new Tarjeta({ nombre, precio, tipo, talla });
		newPago.user = req.session.usuario;

		const card = await newPago.save((err, resultado) => {
			if (err) {
				return res.render('indexpost', {
					mostrar: err
				})
			}
			res.render('indexpost', {
				tituloPagina: 'Bienvenido',
				mostrar: resultado.nombre,
				card
			})
			res.redirect('/tarjeta-pago')
		})

	}
});

app.get('/tarjeta-pago', async (req, res) => {
	const card = await Carrito.find({ user: req.session.usuario }).sort({ date: 'desc' });
	res.render('tarjeta-pago', { card })

});
app.get('/pagar', async (req, res) => {
	const card = await Tarjeta.find({ user: req.session.usuario }).sort({ date: 'desc' });
	res.render('pagar',
	//codigo:code,
	{ card })

});

app.get('/notes/edit/:id', isAuthenticated, async (req, res) => {
	const produ = await Producto.findById(req.params.id);

	res.render('notes/edit-note', { produ });
});

app.put('/notes/edit-note/:id', isAuthenticated, async (req, res) => {
	const { nombre, precio, tipo, talla } = req.body;
	await Producto.findByIdAndUpdate(req.params.id, { nombre, precio, tipo, talla });
	req.flash('success_msg', 'Note Updated Successfully');
	res.redirect('/notes');
});
app.delete('/delete/:id', async (req, res) => {
	await Producto.findByIdAndDelete(req.params.id);
	req.flash('success_msg', 'Note Deleted Successfully');
	res.redirect('/');
});


app.get('/iniciar', (req, res) => {
	res.render('iniciar', {
		tituloPagina: 'Inicio de sesion',

	})
});

app.post('/iniciar', (req, res) => {
	Cliente.findOne({ email: req.body.email }, (err, resultados) => {
		if (err) {
			return console.log(err)
		}
		if (!resultados) {
			return res.render('ingresar', {
				mensaje: "Usuario no encontrado"
			})
		}
		if (!bcrypt.compareSync(req.body.password, resultados.password)) {
			return res.render('ingresar', {
				mensaje: "Contraseña no es correcta"
			})
		}

		//Para crear las variables de sesión
		req.session.usuario = resultados._id
		req.session.email = resultados.nombre
		//avatar=resultados.avatar.toString('base64')

		res.render('ingresar', {
			mensaje: "Bienvenido " + resultados.nombre,
			nombre: resultados.nombre,
			_id: resultados._id,
			sesion: true,
		})
	})
})///termina ingreso


app.get('/salir', (req, res) => {
	req.session.destroy((err) => {
		if (err) return console.log(err)
	})
	// localStorage.setItem('token', '');
	res.redirect('/')
})

app.get('*', (req, res) => {
	res.render('error', {
		titulo: "Error 404",
	})
});

module.exports = app