const mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');


const Schema = mongoose.Schema;

const clienteSchema = new Schema({
	nombre : {
		type : String,
		required : true	,
		trim : true
    },
    apellido : {
		type : String,
		required : true	,
		trim : true
	},
	password :{
		type : String,
		required : true
	},
	email: {
		type : String,
		required : true,
		unique: true,
		trim:true	
    },
    sexo: {
		type : String,
		required : true	,
		trim : true
	},
	avatar:{
		type:Buffer,
	
	}
});


clienteSchema.plugin(uniqueValidator);

const Cliente = mongoose.model('Cliente', clienteSchema);

module.exports = Cliente
