const mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

const Schema = mongoose.Schema;

const carritoSchema = new Schema({
	
	nombre : {
		type : String,
		required : true	,
		trim : true
    },
	precio :{
		type : Number,
		required : true
	},
	tipo: {
		type : String,
		required : true,
		trim:true	
    },
    talla: {
		type : String,
		required : true	,
		trim : true
	},
    user: { type:String, required:true 
    },
	avatar:{
		type:Buffer,
	
	},

});

carritoSchema.plugin(uniqueValidator);

const Carrito = mongoose.model('Carrito', carritoSchema);

module.exports = Carrito