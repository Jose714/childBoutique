const mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

const Schema = mongoose.Schema;

const pagoSchema = new Schema({
	
	nombre : {
		type : String,
		required : true	,
		trim : true
    },
	precio :{
		type : Number,
		required : true
	},
	tipo: {
		type : String,
		required : true,
		trim:true	
    },
    talla: {
		type : String,
		required : true	,
		trim : true
	},
	user: { type:String, },
	avatar:{
		type:Buffer,
	
	},

});

pagoSchema.plugin(uniqueValidator);

const Tarjeta = mongoose.model('Tarjeta', pagoSchema);

module.exports = Tarjeta