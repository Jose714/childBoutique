const mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

const Schema = mongoose.Schema;

const productoSchema = new Schema({
	
	nombre : {
		type : String,
		required : true	,
		unique: true,
		trim : true

    },
	precio :{
		type : Number,
		required : true
	},
	tipo: {
		type : String,
		required : true,
		trim:true	
    },
    talla: {
		type : String,
		required : true	,
		trim : true
	},
	avatar:{
		type:Buffer
	
	},

});

productoSchema.plugin(uniqueValidator);

const Producto = mongoose.model('Producto', productoSchema);

module.exports = Producto